exports.execute = function (args) {
    console.info("App instalado com sucesso:", args);
    renderData();
};