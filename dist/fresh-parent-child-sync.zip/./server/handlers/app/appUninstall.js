exports.execute = function (args) {
    console.info("App desinstalado:", args);
    renderData();
};
