const axios = require("axios");
const FormData = require("form-data");

exports.downloadAttachmentAsFormData = async function (attachment) {
    if (!attachment?.attachment_url || !attachment?.name || !attachment?.content_type) {
        console.error("Erro: Objeto de anexo inválido ou incompleto.");
        return null;
    }
    try {
        const { name, attachment_url, content_type } = attachment;
        const response = await axios.get(attachment_url, {
            responseType: "arraybuffer",
            headers: { Accept: "*/*" },
            maxBodyLength: Infinity
        });

        console.info(response)

        if (response.status !== 200) {
            console.error(`Erro ao baixar anexo ${attachment.id}: Resposta HTTP ${response.status}`);
            return null;
        }


        const formData = new FormData();
        formData.append("attachments[]", response.data, { filename: name, contentType: content_type });
        return { formData, filename: name, contentType: content_type };
    } catch (error) {
        console.error(`Erro ao baixar o anexo ${attachment.id || "desconhecido"}:`, error);
        return null;
    }
};
