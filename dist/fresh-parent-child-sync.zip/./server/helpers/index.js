const { ValidationChain } = require("./ValidationChain");

exports = { ValidationChain }
